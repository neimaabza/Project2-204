/**
 * 
 * @author Neima Abza
 *
 */
public class Notation {
	
	/**
	 * 
	 * @param c a char paramter
	 * @return an int
	 * @throws invaildNotationFormatException
	 */
	public static int Precedence(char c)throws InvalidNotationFormatException {
		switch(c) {
			case '+':
			case '-':
				return 1;
			case '*':
			case '/':
				return 2;
			case '^':
				return 3;
			default:
				return -1;
		}
	}
	/**
	 * 
	 * @param infix
	 * @return result
	 * @throws InvalidNotationFormatException
	 * @throws QueueOverflowException
	 */
	
	public static String convertInfixToPostfix(String infix)throws InvalidNotationFormatException,QueueOverflowException {
		NotationStack<Character> stack = new NotationStack<>(infix.length());
		String result = "";
		for(int i = 0; i < infix.length(); i++) {
			char c = infix.charAt(i);
			if(Character.isLetterOrDigit(c)) {
				result += c;
			} else if (c == '(') {
				stack.push(c);
			} else if (c == ')') {
				while(!stack.isEmpty() && stack.top() != '(') {
					result += stack.pop();
					stack.pop();
				}
			} else {
				while(!stack.isEmpty() && Precedence(c) <= Precedence(stack.top())) {
					result += stack.pop();
				}
				stack.push(c);
			}
		}
		while(!stack.isEmpty()) {
			if(stack.top() == '(') {
				throw new InvalidNotationFormatException();
			}
			result += stack.pop();
		}
		return result;
	}
	
	/**
	 * 
	 * @param postfix
	 * @return
	 * @throws InvalidNotationFormatException
	 */
	
	public static String convertPostfixToInfix(String postfix) throws InvalidNotationFormatException {
		NotationStack<String> theStack = new NotationStack <String>(postfix.length());
            String postFix="";
		for (int i = 0; i < postfix.length(); i++) {
			char c = postfix.charAt(i);
			
			if (c == ' ') {
				continue;
			}
			else if (Character.isLetterOrDigit(c)) {
				theStack.push("" + c);
			}
			else if (c == '+' || c== '*' || c == '/' || c == '-') {
				
				if (theStack.size() < 2) {
					throw new InvalidNotationFormatException("The notation is invalid");
				}
				else {			
					String Op1;
					String Op2;
					Op1 = theStack.pop();
					Op2 = theStack.pop();
					String stringValue = "(" + Op2 + c + Op1 + ")";
					theStack.push(stringValue);
				}
			}
		}
		if (theStack.size() > 1) {
			throw new InvalidNotationFormatException("The notation is invalid");
		}
		else {
			return postFix += theStack.pop();
		}
	}
	/**
	 * 
	 * @param postfixExpr
	 * @return
	 * @throws InvalidNotationFormatException
	 */
	
	public static double evaluatePostfixExpression(String postfixExpr) throws InvalidNotationFormatException{
	
           NotationStack<String> theStack = new NotationStack<String>(postfixExpr.length());
		
		char c;

		for (int i = 0; i < postfixExpr.length(); i++) {

			c = postfixExpr.charAt(i);
			
			if (c == ' ')
				continue;

			else if (Character.isDigit(c) || c == '(')
				theStack.push("" + c );

			else if (c == '+' || c == '*' || c == '/' || c == '-') {

				if (theStack.isEmpty())
					throw new InvalidNotationFormatException(
							"The notation is invalid");

				else {
					
					String nbr1 = theStack.pop();
					String nbr2 = theStack.pop();
					double result;
					switch (c) {
					case '+':
						result = Double.parseDouble(nbr1) + Double.parseDouble(nbr2);
						theStack.push("" + result);
						break;
					
					case '-':
						result = Double.parseDouble(nbr1) - Double.parseDouble(nbr2);
						theStack.push("" + result);
						break;
						
					case '*':
						result = Double.parseDouble(nbr1) * Double.parseDouble(nbr2);
						theStack.push("" + result);
						break;
						
					case '/':
						result = Integer.parseInt(nbr2) / Integer.parseInt(nbr1);
						theStack.push("" + result);
						break;
					
					default:
						break;
					}
				}
			}
		}
		
		if (theStack.size() > 1) {
			throw new InvalidNotationFormatException("The notation is invalid");
		}

		else {
			return Double.parseDouble(theStack.pop());
		}
		
	}
       /**
        * 
        * @param infixExpr
        * @return
        * @throws InvalidNotationFormatException
        * @throws QueueOverflowException
        */

	public static double evaluateInfixExpression(String infixExpr)throws InvalidNotationFormatException,QueueOverflowException  {
		
		String inToPost = convertInfixToPostfix(infixExpr);
	     double inToPostEval =evaluatePostfixExpression(inToPost);
	     
	     return inToPostEval;
	}
	public static int Operation(int val1, int val2, char x) 
	{
		if(x=='+') 
		{
			return val1+val2;
		}
		else if(x=='-') 
		{
			return val1-val2;
		}
		else if(x=='*') 
		{
			return val1*val2;
		}
		else if(x=='/') {
			return val1/val2;
		}
		
		else 
		{
			return 1;
		}
			
			
	}
      
		
}
	
	


