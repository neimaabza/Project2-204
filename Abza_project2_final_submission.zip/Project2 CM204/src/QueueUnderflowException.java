/*
 * @author Neima Abza
 */
public class QueueUnderflowException extends RuntimeException{
	   public QueueUnderflowException() {
		   
	   }
	   /**
	    * @param message - The message that will be displayed for the exception
	    */
	   public QueueUnderflowException(String message){
			super(message);
			}

}
