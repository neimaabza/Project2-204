/*
 * @autor Neima Abza
 */
public class InvalidNotationFormatException extends RuntimeException {
	public InvalidNotationFormatException() {
		this("The notation is invalid");
		
	}
	/*
	 * @param message - The message that will be displayed for the exception
	 */
	public InvalidNotationFormatException(String massage) {
		super(massage);
}

}
