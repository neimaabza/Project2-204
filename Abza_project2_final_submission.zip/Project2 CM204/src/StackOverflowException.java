/**
 * @author Neima Abza
 */

public class StackOverflowException extends RuntimeException {
	public StackOverflowException() {
		
	}
	/**
	 * constructor for Stack Overflow Exception
	 * @param message - The message that will be displayed for the exception
	 */
	public StackOverflowException(String message){
		super(message);
		}

}
