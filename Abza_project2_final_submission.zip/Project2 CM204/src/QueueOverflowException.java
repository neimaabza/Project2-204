/*
 * @author Neima Abza
 */
@SuppressWarnings("serial")
public class QueueOverflowException extends RuntimeException {
	
	public QueueOverflowException() {
		
	}
	/**
	 * 
	 * @param message
	 */
	QueueOverflowException(String message){
	super(message);
	}
	

}