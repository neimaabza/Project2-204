/*
 * @Autor Neima Abza
 */
import java.util.ArrayList;



public class NotationQueue<T>implements QueueInterface<T>{
	private int maxSize;
	private Node firstNode;
	private Node lastNode;
	
	public NotationQueue(int size) {
		this.maxSize= size;
	}
	
	/**
	 * Determines if Queue is empty
	 * Returns:true if Queue is empty, false if not
	 */
	public boolean isEmpty()
	{
		return (firstNode == null)&& (lastNode == null);
	}
	/**
	 * Determines if the Queue is full
	 * Returns:true if the Queue is full, false if not
	 */
	public boolean isFull() {
		int queueSize = size();
		return queueSize == maxSize;
		
	}
	/**
	 * Deletes and returns the element at the front of the Queue
	 */
	public T dequeue()throws QueueUnderflowException{
		if(isEmpty()) {
			throw new QueueUnderflowException(); 
		}
		T front = firstNode.getData();
		firstNode.setData(null);
		firstNode = firstNode.getNextNode();
		if(firstNode == null)
			lastNode =null;
			return front;
	}
	/**
	 * Number of elements in the Queue
	 */
	public int size() {
		int count = 0;
		if(!isEmpty())
			count=1;
		Node node = firstNode;
		while(node != null && node.getNextNode()!= null) {
			count++;
			node=node.getNextNode();
		}
		System.out.println(count);
		return count;
	}
	/**
	 * Adds an element to the end of the Queue
	 */
	public boolean enqueue(T e)throws QueueOverflowException{
		if(isFull()) {
			throw new QueueOverflowException();
		}
		Node newNode = new Node(e , null);
	
		if(isEmpty())
			firstNode = newNode;
		else
			lastNode.setNextNode(newNode);
		lastNode = newNode;
		return true;
		
		
	}
	/**
	 * Returns:string representation of the Queue with elements separated with the delimiter
	 */
	public String toString(String delimiter) {
		StringBuilder builder = new StringBuilder();
		Node node = firstNode;
		while(node.getNextNode()!= null) {
			builder.append(node.getData()+ delimiter);
			node = node.getNextNode();
		}
		if (node.getNextNode() == null && node.getData() != null) {
			builder.append(node.getData());
		}
		return builder.toString();
	}
	/**
	 * Returns the string representation of the elements in the Queue, the beginning of the string is the front of the queue
	 */
	public java.lang.String toString(){
		StringBuilder builder = new StringBuilder();
		Node node = firstNode;
		while(node != null && node.getNextNode()!= null) {
			builder.append(node.getData());
			node = node.getNextNode();
		}
		if (node.getNextNode() == null && node.getData() != null) {
			builder.append(node.getData());
		}
		return builder.toString();
		
	}
	/**
	 * Fills the Queue with the elements of the ArrayList
	 */
	public void fill(ArrayList<T> list) {
		try { 
		    for(T item: list) {
			     enqueue(item);
			}
		
		}catch(QueueOverflowException e){
			
		}
		
	}
	private class Node{
		private T data;
		private Node next;
		Node(T newEntery,Node node){
			this.data = newEntery;
			this.next = node;
		}
		public T getData() {
			return data;
		}
		public void setData(T item) {
			data = item;
		}
		public Node getNextNode() {
			return next;
			
		}
		public void setNextNode(Node node) {
            next = node;			
		}
		
		
	}
}
