/**
 * 
 * @author Neima Abza
 *
 */
@SuppressWarnings("serial")
public class StackUnderflowException extends RuntimeException {
	StackUnderflowException(){
	
	}
		
		/**
		 * @param message - The message that will be displayed for the exception
		 */
		public StackUnderflowException(String massage) {
			super(massage);
	}

}
